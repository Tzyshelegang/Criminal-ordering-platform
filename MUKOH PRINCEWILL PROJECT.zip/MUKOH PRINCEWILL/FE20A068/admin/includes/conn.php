<?php
$mysqli =new mysqli('localhost','root','','caaz');
?>