
Step 1: Extract file.
     first, after you finished download the source code, extract the zip file.

Step 2: Copy project folder.
     second, copy the project folder and paste it into the xampp/htdocs folder.

Step 3: Open xampp.
     open xampp and start the apache and MySQL.

Step 4: Create database.
     click on databases tab and Create database naming “caaz”.

Step 5: Import “caaz.sql”.
      Click on browse file and select “caaz.sql” file which is inside       “database” folder and after import click “go“.

Step 6: Open browser and type folder name.
       Open a browser and go to URL “http://localhost/”.

Step 7: Explore manipulating.
    Final step , Login from the User’s login side. Just provide the Admin’s login detail, it will redirect you to Admin panel.

Admin Login Credentials:
  username: Shele
  password: Jesus@500